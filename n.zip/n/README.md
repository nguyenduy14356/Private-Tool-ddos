# KenosV2
This is the project that took me awhile to make and its finally here. 

# Requirements
<li>A VPS Server (2GB of Ram, 2v Cores)</li>
<li>Bash (If not installed, type <code>sudo apt install bash</code>)</li>

# Installation
Installation is very easy just run the following command
<pre><code>sudo bash installation.sh</pre></code>

# About Kenos
<a href="https://github.com/d3fe4ted/Kenos">Kenos</a> is a project I first thought of as a joke originating from the Geometry Dash map named "<a href="https://geometry-dash-fan.fandom.com/wiki/Kenos">Kenos</a>"

# Recommended Hosting
<li><a href="https://www.cloudways.com/en/">Cloudways</a>
<li><a href="https://crazyrdp.com/linux-vps-hosting/">CrazyRDP</a>
